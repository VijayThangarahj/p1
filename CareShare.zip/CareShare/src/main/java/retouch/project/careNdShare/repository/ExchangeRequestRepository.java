package retouch.project.careNdShare.repository;

import retouch.project.careNdShare.entity.ExchangeRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ExchangeRequestRepository extends JpaRepository<ExchangeRequest, Long> {
    List<ExchangeRequest> findByRequesterId(Long requesterId);
    List<ExchangeRequest> findByRequesterIdAndStatus(Long requesterId, String status);
    List<ExchangeRequest> findByStatus(String status);
    long countByStatus(String status);
}