package retouch.project.careNdShare.entity;

public enum ExchangeStatus {
    PENDING, APPROVED, REJECTED
}