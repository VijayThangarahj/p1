package retouch.project.careNdShare.entity;

public enum ProductStatus {
    PENDING, APPROVED, REJECTED
}